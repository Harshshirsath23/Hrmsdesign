import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { CheckCircle2, Clock, XCircle, Calendar as CalendarIcon } from "lucide-react";
import { MOCK_DEPARTMENTS, MOCK_DESIGNATIONS, MOCK_TEAMS } from "../../modules/attendance/mockData";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Button } from "../ui/button";
import { Calendar } from "../ui/calendar";
import { format } from "date-fns";
import { cn } from "../ui/utils";

interface WhosInTodayProps {
  data: {
    onTime: number;
    lateIn: number;
    notYetIn: number;
  };
  filters: {
    date: Date;
    department: string;
    designation: string;
    team: string;
  };
  setFilters: (filters: any) => void;
}

export function WhosInToday({ data, filters, setFilters }: WhosInTodayProps) {
  const chartData = [
    { name: "On Time", value: data.onTime, color: "#10b981" },
    { name: "Late In", value: data.lateIn, color: "#f59e0b" },
    { name: "Not Yet In", value: data.notYetIn, color: "#ef4444" },
  ];

  const updateFilter = (key: string, value: any) => {
    setFilters((prev: any) => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="shadow-sm border-border">
      <CardHeader className="border-b border-border py-4 px-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <CardTitle className="text-base font-bold text-foreground">Who's In Today</CardTitle>
          
          <div className="flex flex-wrap items-center gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "h-9 justify-start text-left font-normal w-[160px]",
                    !filters.date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.date ? format(filters.date, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="single"
                  selected={filters.date}
                  onSelect={(d) => d && updateFilter("date", d)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>

            <Select value={filters.department} onValueChange={(v) => updateFilter("department", v)}>
              <SelectTrigger className="h-9 w-[140px] text-xs">
                <SelectValue placeholder="Dept" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Dept</SelectItem>
                {MOCK_DEPARTMENTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>

            <Select value={filters.team} onValueChange={(v) => updateFilter("team", v)}>
              <SelectTrigger className="h-9 w-[140px] text-xs">
                <SelectValue placeholder="Team" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Teams</SelectItem>
                {MOCK_TEAMS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Side: Donut Chart */}
          <div className="h-[250px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  animationBegin={0}
                  animationDuration={1500}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'var(--card)', 
                    borderColor: 'var(--border)',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-bold text-foreground">{data.onTime + data.lateIn}</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Present</span>
            </div>
          </div>

          {/* Right Side: Status Cards */}
          <div className="flex flex-col justify-center gap-3">
            <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-secondary/30">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                </div>
                <span className="text-sm font-medium">On Time</span>
              </div>
              <span className="text-lg font-bold">{data.onTime}</span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-secondary/30">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Clock className="w-4 h-4 text-amber-500" />
                </div>
                <span className="text-sm font-medium">Late In</span>
              </div>
              <span className="text-lg font-bold">{data.lateIn}</span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-secondary/30">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center">
                  <XCircle className="w-4 h-4 text-red-500" />
                </div>
                <span className="text-sm font-medium">Not Yet In</span>
              </div>
              <span className="text-lg font-bold">{data.notYetIn}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
