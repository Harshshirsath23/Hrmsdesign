import { Clock, UserCheck, UserMinus, Calendar, AlertCircle, FileText } from "lucide-react";
import { Card, CardContent } from "../ui/card";

interface AnalyticsPanelProps {
  metrics: {
    avgWorkHours: number;
    totalPresent: number;
    totalAbsent: number;
    holidays: number;
    lateLogins: number;
    halfDays: number;
  };
}

export function AnalyticsPanel({ metrics }: AnalyticsPanelProps) {
  const items = [
    { label: "Avg Work Hours", value: `${metrics.avgWorkHours.toFixed(1)}h`, icon: Clock, color: "text-blue-500", bg: "bg-blue-500/10" },
    { label: "Total Present", value: metrics.totalPresent, icon: UserCheck, color: "text-green-500", bg: "bg-green-500/10" },
    { label: "Total Absent", value: metrics.totalAbsent, icon: UserMinus, color: "text-red-500", bg: "bg-red-500/10" },
    { label: "Holidays", value: metrics.holidays, icon: Calendar, color: "text-purple-500", bg: "bg-purple-500/10" },
    { label: "Late Logins", value: metrics.lateLogins, icon: AlertCircle, color: "text-amber-500", bg: "bg-amber-500/10" },
    { label: "Half Days", value: metrics.halfDays, icon: FileText, color: "text-indigo-500", bg: "bg-indigo-500/10" },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
      {items.map((item) => (
        <Card key={item.label} className="shadow-sm border-border overflow-hidden">
          <CardContent className="p-4 flex items-center gap-4">
            <div className={`w-10 h-10 rounded-lg ${item.bg} flex items-center justify-center flex-shrink-0`}>
              <item.icon className={`w-5 h-5 ${item.color}`} />
            </div>
            <div>
              <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">{item.label}</p>
              <p className="text-xl font-bold text-foreground">{item.value}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
