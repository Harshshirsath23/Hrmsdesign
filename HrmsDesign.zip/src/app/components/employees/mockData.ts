export interface Employee {
  id: string;
  name: string;
  employeeId: string;
  designation: string;
  department: string;
  team: string;
  email: string;
  phone: string;
  joiningDate: string;
  location: string;
  status: "Active" | "Inactive" | "On Leave";
  avatar?: string;
  initials: string;
  avatarColor: string;
  // Profile details
  dateOfBirth: string;
  gender: string;
  maritalStatus: string;
  bloodGroup: string;
  nationality: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  // Bank details
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  pfNumber: string;
  esiNumber: string;
  // Family
  family: {
    name: string;
    relationship: string;
    dob: string;
    occupation: string;
  }[];
  // Passport
  passportNumber: string;
  passportExpiry: string;
  visaType: string;
  visaExpiry: string;
  visaCountry: string;
  // Position History
  positionHistory: {
    title: string;
    department: string;
    from: string;
    to: string;
    reportingTo: string;
  }[];
  // Previous Employment
  previousEmployment: {
    company: string;
    designation: string;
    from: string;
    to: string;
    reasonForLeaving: string;
  }[];
  // Salary
  basicSalary: number;
  hra: number;
  conveyance: number;
  medicalAllowance: number;
  specialAllowance: number;
  grossSalary: number;
  pf: number;
  tds: number;
  netSalary: number;
}

export const employees: Employee[] = [
  {
    id: "1",
    name: "Arjun Sharma",
    employeeId: "EMP-001",
    designation: "Senior Developer",
    department: "Engineering",
    team: "Frontend",
    email: "arjun.sharma@company.com",
    phone: "+91 98765 43210",
    joiningDate: "2021-03-15",
    location: "Bangalore",
    status: "Active",
    avatar: "https://images.unsplash.com/photo-1651684215020-f7a5b6610f23?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200",
    initials: "AS",
    avatarColor: "#4F46E5",
    dateOfBirth: "1992-07-20",
    gender: "Male",
    maritalStatus: "Married",
    bloodGroup: "B+",
    nationality: "Indian",
    address: "42, Koramangala 5th Block",
    city: "Bangalore",
    state: "Karnataka",
    pincode: "560095",
    bankName: "HDFC Bank",
    accountNumber: "XXXX XXXX 4521",
    ifscCode: "HDFC0001234",
    pfNumber: "KN/BAN/12345/001",
    esiNumber: "ESI/2021/001234",
    family: [
      { name: "Priya Sharma", relationship: "Spouse", dob: "1994-03-10", occupation: "Teacher" },
      { name: "Ramesh Sharma", relationship: "Father", dob: "1962-11-05", occupation: "Retired" },
      { name: "Sunita Sharma", relationship: "Mother", dob: "1965-08-14", occupation: "Homemaker" },
    ],
    passportNumber: "J9876543",
    passportExpiry: "2029-05-12",
    visaType: "Business Visa",
    visaExpiry: "2024-12-31",
    visaCountry: "United States",
    positionHistory: [
      { title: "Senior Developer", department: "Engineering", from: "2023-01-01", to: "Present", reportingTo: "Vikram Nair" },
      { title: "Developer", department: "Engineering", from: "2021-03-15", to: "2022-12-31", reportingTo: "Vikram Nair" },
    ],
    previousEmployment: [
      { company: "TechSolutions Pvt Ltd", designation: "Junior Developer", from: "2018-06-01", to: "2021-03-10", reasonForLeaving: "Better Opportunity" },
      { company: "StartupXYZ", designation: "Intern", from: "2017-11-01", to: "2018-05-31", reasonForLeaving: "Contract End" },
    ],
    basicSalary: 75000,
    hra: 30000,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 10750,
    grossSalary: 120000,
    pf: 9000,
    tds: 8500,
    netSalary: 102500,
  },
  {
    id: "2",
    name: "Priya Nair",
    employeeId: "EMP-002",
    designation: "HR Manager",
    department: "Human Resources",
    team: "Talent Acquisition",
    email: "priya.nair@company.com",
    phone: "+91 98765 43211",
    joiningDate: "2020-06-01",
    location: "Mumbai",
    status: "Active",
    avatar: "https://images.unsplash.com/photo-1706824265660-5ca5effaf122?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200",
    initials: "PN",
    avatarColor: "#0891B2",
    dateOfBirth: "1990-04-15",
    gender: "Female",
    maritalStatus: "Single",
    bloodGroup: "A+",
    nationality: "Indian",
    address: "12, Bandra West, Turner Road",
    city: "Mumbai",
    state: "Maharashtra",
    pincode: "400050",
    bankName: "ICICI Bank",
    accountNumber: "XXXX XXXX 7832",
    ifscCode: "ICIC0002345",
    pfNumber: "MH/MUM/23456/002",
    esiNumber: "ESI/2020/002345",
    family: [
      { name: "Mohan Nair", relationship: "Father", dob: "1960-09-20", occupation: "Business" },
      { name: "Latha Nair", relationship: "Mother", dob: "1963-02-28", occupation: "Homemaker" },
    ],
    passportNumber: "K1234567",
    passportExpiry: "2027-08-22",
    visaType: "Tourist Visa",
    visaExpiry: "2024-06-30",
    visaCountry: "United Kingdom",
    positionHistory: [
      { title: "HR Manager", department: "Human Resources", from: "2022-07-01", to: "Present", reportingTo: "Deepa Menon" },
      { title: "HR Executive", department: "Human Resources", from: "2020-06-01", to: "2022-06-30", reportingTo: "Deepa Menon" },
    ],
    previousEmployment: [
      { company: "GlobalHR Solutions", designation: "HR Coordinator", from: "2016-08-01", to: "2020-05-28", reasonForLeaving: "Career Growth" },
    ],
    basicSalary: 65000,
    hra: 26000,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 9750,
    grossSalary: 105000,
    pf: 7800,
    tds: 7200,
    netSalary: 90000,
  },
  {
    id: "3",
    name: "Vikram Mehta",
    employeeId: "EMP-003",
    designation: "Product Manager",
    department: "Product",
    team: "Product Strategy",
    email: "vikram.mehta@company.com",
    phone: "+91 98765 43212",
    joiningDate: "2019-09-10",
    location: "Delhi",
    status: "Active",
    avatar: "https://images.unsplash.com/photo-1625929664135-197db5f6c857?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200",
    initials: "VM",
    avatarColor: "#059669",
    dateOfBirth: "1988-12-03",
    gender: "Male",
    maritalStatus: "Married",
    bloodGroup: "O+",
    nationality: "Indian",
    address: "78, Vasant Kunj Phase 2",
    city: "New Delhi",
    state: "Delhi",
    pincode: "110070",
    bankName: "SBI",
    accountNumber: "XXXX XXXX 9012",
    ifscCode: "SBIN0003456",
    pfNumber: "DL/DEL/34567/003",
    esiNumber: "ESI/2019/003456",
    family: [
      { name: "Anita Mehta", relationship: "Spouse", dob: "1991-06-25", occupation: "Doctor" },
      { name: "Rahul Mehta", relationship: "Son", dob: "2018-03-15", occupation: "Student" },
    ],
    passportNumber: "L7654321",
    passportExpiry: "2028-11-10",
    visaType: "Work Visa",
    visaExpiry: "2025-03-15",
    visaCountry: "Germany",
    positionHistory: [
      { title: "Product Manager", department: "Product", from: "2021-04-01", to: "Present", reportingTo: "CEO" },
      { title: "Senior Business Analyst", department: "Product", from: "2019-09-10", to: "2021-03-31", reportingTo: "CTO" },
    ],
    previousEmployment: [
      { company: "BigTech Corp", designation: "Business Analyst", from: "2015-01-15", to: "2019-09-05", reasonForLeaving: "Better Package" },
      { company: "ConsultingFirm", designation: "Analyst Intern", from: "2013-06-01", to: "2014-12-31", reasonForLeaving: "Full Time Opportunity" },
    ],
    basicSalary: 90000,
    hra: 36000,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 19750,
    grossSalary: 150000,
    pf: 10800,
    tds: 15000,
    netSalary: 124200,
  },
  {
    id: "4",
    name: "Sneha Krishnan",
    employeeId: "EMP-004",
    designation: "UI/UX Designer",
    department: "Design",
    team: "User Experience",
    email: "sneha.krishnan@company.com",
    phone: "+91 98765 43213",
    joiningDate: "2022-01-05",
    location: "Chennai",
    status: "On Leave",
    avatar: "https://images.unsplash.com/photo-1670852077053-6f9a8b3b0d75?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200",
    initials: "SK",
    avatarColor: "#DC2626",
    dateOfBirth: "1995-08-30",
    gender: "Female",
    maritalStatus: "Single",
    bloodGroup: "AB+",
    nationality: "Indian",
    address: "5, Anna Nagar East",
    city: "Chennai",
    state: "Tamil Nadu",
    pincode: "600102",
    bankName: "Axis Bank",
    accountNumber: "XXXX XXXX 3456",
    ifscCode: "UTIB0004567",
    pfNumber: "TN/CHE/45678/004",
    esiNumber: "ESI/2022/004567",
    family: [
      { name: "Ravi Krishnan", relationship: "Father", dob: "1965-03-22", occupation: "Engineer" },
      { name: "Meena Krishnan", relationship: "Mother", dob: "1968-10-01", occupation: "Nurse" },
    ],
    passportNumber: "M3456789",
    passportExpiry: "2030-02-18",
    visaType: "Student Visa",
    visaExpiry: "2023-09-30",
    visaCountry: "Singapore",
    positionHistory: [
      { title: "UI/UX Designer", department: "Design", from: "2022-01-05", to: "Present", reportingTo: "Anand Shenoy" },
    ],
    previousEmployment: [
      { company: "CreativeStudio", designation: "Junior Designer", from: "2020-07-01", to: "2021-12-31", reasonForLeaving: "Relocation" },
    ],
    basicSalary: 55000,
    hra: 22000,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 8750,
    grossSalary: 90000,
    pf: 6600,
    tds: 5000,
    netSalary: 78400,
  },
  {
    id: "5",
    name: "Rajesh Kumar",
    employeeId: "EMP-005",
    designation: "DevOps Engineer",
    department: "Engineering",
    team: "Infrastructure",
    email: "rajesh.kumar@company.com",
    phone: "+91 98765 43214",
    joiningDate: "2021-11-20",
    location: "Hyderabad",
    status: "Active",
    avatar: "https://images.unsplash.com/photo-1680515837641-bb4b6cbebe8a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200",
    initials: "RK",
    avatarColor: "#7C3AED",
    dateOfBirth: "1993-01-12",
    gender: "Male",
    maritalStatus: "Married",
    bloodGroup: "O-",
    nationality: "Indian",
    address: "22, Jubilee Hills Road No. 36",
    city: "Hyderabad",
    state: "Telangana",
    pincode: "500033",
    bankName: "Kotak Mahindra Bank",
    accountNumber: "XXXX XXXX 8901",
    ifscCode: "KKBK0005678",
    pfNumber: "TS/HYD/56789/005",
    esiNumber: "ESI/2021/005678",
    family: [
      { name: "Kavitha Kumar", relationship: "Spouse", dob: "1995-05-18", occupation: "Software Engineer" },
      { name: "Aryan Kumar", relationship: "Son", dob: "2021-08-10", occupation: "Infant" },
    ],
    passportNumber: "N8765432",
    passportExpiry: "2031-07-05",
    visaType: "Business Visa",
    visaExpiry: "2025-01-15",
    visaCountry: "Australia",
    positionHistory: [
      { title: "DevOps Engineer", department: "Engineering", from: "2021-11-20", to: "Present", reportingTo: "Kiran Bose" },
    ],
    previousEmployment: [
      { company: "CloudTech Solutions", designation: "Systems Engineer", from: "2018-03-01", to: "2021-11-15", reasonForLeaving: "Better Growth" },
    ],
    basicSalary: 70000,
    hra: 28000,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 12750,
    grossSalary: 115000,
    pf: 8400,
    tds: 9000,
    netSalary: 97600,
  },
  {
    id: "6",
    name: "Ananya Iyer",
    employeeId: "EMP-006",
    designation: "Marketing Specialist",
    department: "Marketing",
    team: "Digital Marketing",
    email: "ananya.iyer@company.com",
    phone: "+91 98765 43215",
    joiningDate: "2023-02-14",
    location: "Pune",
    status: "Active",
    avatar: "https://images.unsplash.com/photo-1758599543146-f263d3b3321e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=200",
    initials: "AI",
    avatarColor: "#D97706",
    dateOfBirth: "1997-11-25",
    gender: "Female",
    maritalStatus: "Single",
    bloodGroup: "A-",
    nationality: "Indian",
    address: "8, Koregaon Park Lane 5",
    city: "Pune",
    state: "Maharashtra",
    pincode: "411001",
    bankName: "Yes Bank",
    accountNumber: "XXXX XXXX 6789",
    ifscCode: "YESB0006789",
    pfNumber: "MH/PUN/67890/006",
    esiNumber: "ESI/2023/006789",
    family: [
      { name: "Suresh Iyer", relationship: "Father", dob: "1968-07-15", occupation: "Professor" },
      { name: "Geetha Iyer", relationship: "Mother", dob: "1971-04-30", occupation: "Doctor" },
    ],
    passportNumber: "P2345678",
    passportExpiry: "2032-09-20",
    visaType: "Tourist Visa",
    visaExpiry: "2024-04-10",
    visaCountry: "France",
    positionHistory: [
      { title: "Marketing Specialist", department: "Marketing", from: "2023-02-14", to: "Present", reportingTo: "Neeraj Shah" },
    ],
    previousEmployment: [
      { company: "AdAgency Pro", designation: "Content Writer", from: "2021-01-01", to: "2023-02-05", reasonForLeaving: "Higher Studies" },
    ],
    basicSalary: 45000,
    hra: 18000,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 7750,
    grossSalary: 75000,
    pf: 5400,
    tds: 3000,
    netSalary: 66600,
  },
  {
    id: "7",
    name: "Karthik Reddy",
    employeeId: "EMP-007",
    designation: "Data Analyst",
    department: "Analytics",
    team: "Business Intelligence",
    email: "karthik.reddy@company.com",
    phone: "+91 98765 43216",
    joiningDate: "2022-08-01",
    location: "Bangalore",
    status: "Inactive",
    initials: "KR",
    avatarColor: "#0F766E",
    dateOfBirth: "1994-05-08",
    gender: "Male",
    maritalStatus: "Single",
    bloodGroup: "B-",
    nationality: "Indian",
    address: "15, HSR Layout Sector 4",
    city: "Bangalore",
    state: "Karnataka",
    pincode: "560102",
    bankName: "Punjab National Bank",
    accountNumber: "XXXX XXXX 1234",
    ifscCode: "PUNB0007890",
    pfNumber: "KN/BAN/78901/007",
    esiNumber: "ESI/2022/007890",
    family: [
      { name: "Narayan Reddy", relationship: "Father", dob: "1963-12-18", occupation: "Farmer" },
      { name: "Vimala Reddy", relationship: "Mother", dob: "1966-06-22", occupation: "Homemaker" },
    ],
    passportNumber: "Q9876543",
    passportExpiry: "2028-04-14",
    visaType: "",
    visaExpiry: "",
    visaCountry: "",
    positionHistory: [
      { title: "Data Analyst", department: "Analytics", from: "2022-08-01", to: "2024-12-31", reportingTo: "Sanjay Patel" },
    ],
    previousEmployment: [
      { company: "DataFirst Inc", designation: "Junior Analyst", from: "2019-05-01", to: "2022-07-25", reasonForLeaving: "Better Opportunity" },
    ],
    basicSalary: 58000,
    hra: 23200,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 9550,
    grossSalary: 95000,
    pf: 6960,
    tds: 6000,
    netSalary: 82040,
  },
  {
    id: "8",
    name: "Divya Pillai",
    employeeId: "EMP-008",
    designation: "Finance Executive",
    department: "Finance",
    team: "Accounts",
    email: "divya.pillai@company.com",
    phone: "+91 98765 43217",
    joiningDate: "2020-11-30",
    location: "Kochi",
    status: "Active",
    initials: "DP",
    avatarColor: "#BE185D",
    dateOfBirth: "1993-09-14",
    gender: "Female",
    maritalStatus: "Married",
    bloodGroup: "O+",
    nationality: "Indian",
    address: "34, Edapally Junction",
    city: "Kochi",
    state: "Kerala",
    pincode: "682024",
    bankName: "Federal Bank",
    accountNumber: "XXXX XXXX 5678",
    ifscCode: "FDRL0008901",
    pfNumber: "KL/KOC/89012/008",
    esiNumber: "ESI/2020/008901",
    family: [
      { name: "Sunil Pillai", relationship: "Spouse", dob: "1990-02-14", occupation: "Architect" },
      { name: "George Pillai", relationship: "Father", dob: "1960-07-07", occupation: "Retired" },
    ],
    passportNumber: "R1234567",
    passportExpiry: "2026-12-03",
    visaType: "Tourist Visa",
    visaExpiry: "2024-08-20",
    visaCountry: "UAE",
    positionHistory: [
      { title: "Finance Executive", department: "Finance", from: "2020-11-30", to: "Present", reportingTo: "CFO" },
    ],
    previousEmployment: [
      { company: "CA Firm Nair & Associates", designation: "Accounts Assistant", from: "2017-07-01", to: "2020-11-20", reasonForLeaving: "Corporate Job" },
    ],
    basicSalary: 48000,
    hra: 19200,
    conveyance: 3000,
    medicalAllowance: 1250,
    specialAllowance: 8550,
    grossSalary: 80000,
    pf: 5760,
    tds: 4200,
    netSalary: 70040,
  },
];

export const departments = ["All Departments", "Engineering", "Human Resources", "Product", "Design", "Marketing", "Analytics", "Finance"];
export const teams = ["All Teams", "Frontend", "Infrastructure", "Talent Acquisition", "Product Strategy", "User Experience", "Digital Marketing", "Business Intelligence", "Accounts"];
export const designations = ["All Designations", "Senior Developer", "HR Manager", "Product Manager", "UI/UX Designer", "DevOps Engineer", "Marketing Specialist", "Data Analyst", "Finance Executive"];
