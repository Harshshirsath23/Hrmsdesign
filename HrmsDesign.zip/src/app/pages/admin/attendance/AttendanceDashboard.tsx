import { useState, useMemo } from "react";
import { AttendanceFilterBar } from "../../../components/attendance/AttendanceFilterBar";
import { WorkHoursSummary } from "../../../components/attendance/WorkHoursSummary";
import { AnalyticsPanel } from "../../../components/attendance/AnalyticsPanel";
import { WhosInToday } from "../../../components/attendance/WhosInToday";
import { EmployeePreviewList } from "../../../components/attendance/EmployeePreviewList";
import { MOCK_ATTENDANCE } from "../../../modules/attendance/mockData";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from "date-fns";

export function AttendanceDashboard() {
  // Global Filters
  const [globalFilters, setGlobalFilters] = useState({
    month: String(new Date().getMonth() + 1),
    year: String(new Date().getFullYear()),
    department: "all",
    designation: "all",
    team: "all",
    search: "",
  });

  // Whos In Today Filters
  const [whosInFilters, setWhosInFilters] = useState({
    date: new Date(),
    department: "all",
    designation: "all",
    team: "all",
  });

  // 1. Filtered data for the Work Hours & Analytics (Monthly)
  const filteredMonthlyData = useMemo(() => {
    return MOCK_ATTENDANCE.filter(record => {
      const recordDate = new Date(record.date);
      const matchesMonth = (recordDate.getMonth() + 1) === Number(globalFilters.month);
      const matchesYear = recordDate.getFullYear() === Number(globalFilters.year);
      const matchesDept = globalFilters.department === "all" || record.department === globalFilters.department;
      const matchesTeam = globalFilters.team === "all" || record.team === globalFilters.team;
      const matchesDesig = globalFilters.designation === "all" || record.designation === globalFilters.designation;
      const matchesSearch = !globalFilters.search || 
        record.employeeName.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
        record.employeeId.toLowerCase().includes(globalFilters.search.toLowerCase());

      return matchesMonth && matchesYear && matchesDept && matchesTeam && matchesDesig && matchesSearch;
    });
  }, [globalFilters]);

  // 2. Filtered data for "Who's In Today" (Specific Date)
  const filteredDailyData = useMemo(() => {
    return MOCK_ATTENDANCE.filter(record => {
      const isDay = isSameDay(new Date(record.date), whosInFilters.date);
      const matchesDept = whosInFilters.department === "all" || record.department === whosInFilters.department;
      const matchesTeam = whosInFilters.team === "all" || record.team === whosInFilters.team;
      
      return isDay && matchesDept && matchesTeam;
    });
  }, [whosInFilters]);

  // 3. Calculate Work Hours Chart Data
  const chartData = useMemo(() => {
    const startDate = startOfMonth(new Date(Number(globalFilters.year), Number(globalFilters.month) - 1));
    const endDate = endOfMonth(startDate);
    const days = eachDayOfInterval({ start: startDate, end: endDate });

    return days.map(day => {
      const dateStr = format(day, "yyyy-MM-dd");
      const dayRecords = filteredMonthlyData.filter(r => r.date === dateStr && r.status !== "Week Off" && r.status !== "Holiday");
      
      const avgHours = dayRecords.length > 0 
        ? dayRecords.reduce((acc, curr) => acc + curr.workHours, 0) / dayRecords.length 
        : 0;

      return {
        day: format(day, "dd MMM"),
        hours: Number(avgHours.toFixed(1))
      };
    });
  }, [filteredMonthlyData, globalFilters]);

  // 4. Calculate Analytics Metrics
  const metrics = useMemo(() => {
    const presentRecords = filteredMonthlyData.filter(r => r.status === "Present");
    const absentRecords = filteredMonthlyData.filter(r => r.status === "Absent");
    const holidayRecords = filteredMonthlyData.filter(r => r.status === "Holiday");
    const lateRecords = filteredMonthlyData.filter(r => r.isLate);
    const halfDayRecords = filteredMonthlyData.filter(r => r.isHalfDay);

    const totalWorkHours = presentRecords.reduce((acc, curr) => acc + curr.workHours, 0);
    const avgWorkHours = presentRecords.length > 0 ? totalWorkHours / presentRecords.length : 0;

    return {
      avgWorkHours,
      totalPresent: presentRecords.length,
      totalAbsent: absentRecords.length,
      holidays: holidayRecords.length,
      lateLogins: lateRecords.length,
      halfDays: halfDayRecords.length,
    };
  }, [filteredMonthlyData]);

  // 5. Calculate "Who's In Today" Metrics
  const whosInMetrics = useMemo(() => {
    const onTime = filteredDailyData.filter(r => r.status === "Present" && !r.isLate).length;
    const lateIn = filteredDailyData.filter(r => r.isLate).length;
    const notYetIn = filteredDailyData.filter(r => r.status === "Absent").length;

    return { onTime, lateIn, notYetIn };
  }, [filteredDailyData]);

  // 6. Employee Preview List (Top 5)
  const employeePreview = useMemo(() => {
    return filteredDailyData
      .slice(0, 5)
      .map(r => ({
        id: r.id,
        name: r.employeeName,
        department: r.department,
        loginTime: r.firstIn,
        status: r.isLate ? "Late In" : (r.status === "Absent" ? "Not Yet In" : "On Time") as any
      }));
  }, [filteredDailyData]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col gap-1">
        <h2 className="text-2xl font-bold text-foreground">Attendance Dashboard</h2>
        <p className="text-sm text-muted-foreground">Monitor and analyze employee attendance patterns across the organization.</p>
      </div>

      <AttendanceFilterBar 
        filters={globalFilters} 
        setFilters={setGlobalFilters} 
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <WorkHoursSummary data={chartData} />
        </div>
        <div className="lg:col-span-1">
          <AnalyticsPanel metrics={metrics} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <WhosInToday 
            data={whosInMetrics} 
            filters={whosInFilters} 
            setFilters={setWhosInFilters} 
          />
        </div>
        <div className="lg:col-span-1">
          <div className="bg-card border border-border rounded-xl p-4 shadow-sm h-full">
            <EmployeePreviewList employees={employeePreview} />
          </div>
        </div>
      </div>
    </div>
  );
}
